# Docker Mastery: The Complete Toolset From a Docker Captain

> Build, compose, deploy, and manage Docker containers from development to DevOps based Swarm clusters

This repo is for use in my Udemy Courses "Docker Mastery" and "Swarm Mastery"

Get these courses for just $10 using my "cheapest on the Internet" coupon link:

https://bretfisher.com/dockermastery

https://bretfisher.com/dockerswarmmastery

Other courses, coupons, and free DevOps and Docker resources at https://www.bretfisher.com/docker

Feel free to create issues or PRs if you find a problem with examples in this repo!
